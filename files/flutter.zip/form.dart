import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: MinimalForm()));

class MinimalForm extends StatelessWidget {
  const MinimalForm({super.key});

  @override
  Widget build(BuildContext context) {
    // Key used to interact with the Form state for validation
    final formKey = GlobalKey<FormState>();

    return Scaffold(
      body: SafeArea(
        child: Form(
          key: formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (value) => value!.isEmpty ? 'Required' : null,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (value) => value!.isEmpty ? 'Required' : null,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true, // Hides the text for passwords
                validator: (value) => value!.length < 6 ? 'Password too short' : null,
              ),
              ElevatedButton(
                onPressed: () {
                  // Trigger validation on button press
                  if (formKey.currentState!.validate()) {
                    // Show a snackbar message to the user
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Form submitted successfully!')),
                    );
                  }
                },
                child: const Text('Submit'),
              )
            ],
          ),
        ),
      ),
    );
  }
}