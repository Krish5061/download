import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: App()));

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Minimal UI')),
    body: Column(children: [
      const Text('Simple Text'),
      const TextField(decoration: InputDecoration(hintText: 'Type here')),
      ElevatedButton(onPressed: () {}, child: const Text('Button')),
      const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Icon(Icons.star), Text('Row Item')],
      ),
      Expanded(
        child: ListView(
          children: const [ListTile(title: Text('List Item 1'))],
        ),
      )
    ]),
    floatingActionButton: FloatingActionButton(
      onPressed: () {}, 
      child: const Icon(Icons.add)
    ),
  );
}