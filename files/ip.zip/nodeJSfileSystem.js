const fs = require('fs');

fs.writeFile('example.txt', 'Hello World!', (err) => {
    if (err) throw err;
    console.log('File created and data written.');

    fs.readFile('example.txt', 'utf8', (err, data) => {
        if (err) throw err;
        console.log('File content:', data);

        fs.appendFile('example.txt', '\nThis is Node.js!', (err) => {
            if (err) throw err;
            console.log('Data appended.');

            fs.readFile('example.txt', 'utf8', (err, updatedData) => {
                if (err) throw err;
                console.log('Updated file content:\n', updatedData);

                fs.unlink('example.txt', (err) => {
                    if (err) throw err;
                    console.log('File deleted.');
                });
            });
        });
    });
});
