// App.jsx
import React, { useState } from "react";

// Child component receives props
function Greeting({ name }) {
  return <h2>Hello, {name}!</h2>;
}

function App() {
  // State to manage input value
  const [name, setName] = useState("");

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>React Props and State Demo</h1>

      {/* Input to update state */}
      <input
        type="text"
        placeholder="Enter your name"
        value={name} // state
        onChange={(e) => setName(e.target.value)}
        style={{ padding: "5px", marginRight: "10px" }}
      />

      {/* Button to clear state */}
      <button onClick={() => setName("")}>Clear</button>

      {/* Pass state as prop to child */}
      <Greeting name={name || "Guest"} />
    </div>
  );
}

export default App;
