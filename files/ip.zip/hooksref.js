// App.jsx
import React, { useState, useEffect, useRef } from "react";

function App() {
  const [count, setCount] = useState(0); // State
  const inputRef = useRef(null); // Ref to input element

  // useEffect runs after every render where `count` changes
  useEffect(() => {
    console.log(`Count has changed to ${count}`);
    document.title = `Count: ${count}`;
  }, [count]); // dependency array

  // Focus input field using ref
  const focusInput = () => {
    inputRef.current.focus();
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>React Hooks Demo</h1>

      <div style={{ marginBottom: "10px" }}>
        <button onClick={() => setCount(count + 1)}>Increase Count</button>
        <span style={{ marginLeft: "10px" }}>Count: {count}</span>
      </div>

      <div>
        <input ref={inputRef} placeholder="Type something..." />
        <button onClick={focusInput} style={{ marginLeft: "10px" }}>
          Focus Input
        </button>
      </div>
    </div>
  );
}

export default App;
