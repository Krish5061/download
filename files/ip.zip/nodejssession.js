// app.js
const express = require("express");
const session = require("express-session");

const app = express();
const PORT = 3000;

// Middleware to parse URL-encoded form data
app.use(express.urlencoded({ extended: true }));

// Session middleware
app.use(
  session({
    secret: "mySecretKey", // change to a secure key
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }, // session expires in 1 min
  })
);

// Home route
app.get("/", (req, res) => {
  // Initialize session counter
  if (!req.session.views) {
    req.session.views = 1;
  } else {
    req.session.views++;
  }

  res.send(`
    <h1>Express Session Demo</h1>
    <p>Number of visits this session: ${req.session.views}</p>
    <form method="POST" action="/setname">
      <input type="text" name="username" placeholder="Enter your name" required/>
      <button type="submit">Set Name</button>
    </form>
    <p>Your name in session: ${req.session.username || "Not set"}</p>
    <a href="/destroy">End Session</a>
  `);
});

// Set name in session
app.post("/setname", (req, res) => {
  const { username } = req.body;
  req.session.username = username;
  res.redirect("/");
});

// Destroy session
app.get("/destroy", (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.send("Error destroying session");
    res.send("<h1>Session ended</h1><a href='/'>Go Home</a>");
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
