def caesar_encrypt_upper(msg, key):
    return "".join([chr((ord(c) - 65 + key) % 26 + 65) if c.isupper() else c for c in msg])

def caesar_decrypt_upper(msg, key):
    return "".join([chr((ord(c) - 65 - key) % 26 + 65) if c.isupper() else c for c in msg])

def transpose_encrypt(msg):
    mid = len(msg) // 2
    return msg[mid:] + msg[:mid]

def transpose_decrypt(msg):
    mid = (len(msg) + 1) // 2
    return msg[mid:] + msg[:mid]

message = "HELLOEXAM"
key = 3
sub_cipher = caesar_encrypt_upper(message, key)
prod_cipher = transpose_encrypt(sub_cipher)
trans_back = transpose_decrypt(prod_cipher)
original = caesar_decrypt_upper(trans_back, key)

print(f"Original: {message}")
print(f"After Substitution: {sub_cipher}")
print(f"After Transposition: {prod_cipher}")
print(f"Decrypted: {original}")