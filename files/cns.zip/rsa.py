def gcd(a, b):
    while b: a, b = b, a % b
    return a

def modinv(e, phi):
    return next(d for d in range(2, phi) if (d * e) % phi == 1)

p, q = 11, 13
n = p * q
phi = (p - 1) * (q - 1)
e = 7
d = modinv(e, phi)

print(f"Public Key (n, e): ({n}, {e})")
print(f"Private Key (n, d): ({n}, {d})\n")

message = "HI"
print(f"Original Message: {message}")

cipher = [pow(ord(c), e, n) for c in message]
print(f"Encrypted: {cipher}")

decrypted = "".join([chr(pow(c, d, n)) for c in cipher])
print(f"Decrypted: {decrypted}")

signature = [pow(ord(c), d, n) for c in message]
print(f"Digital Signature: {signature}")

verified = "".join([chr(pow(c, e, n)) for c in signature])
print(f"Verified Message: {verified}")