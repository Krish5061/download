def caesar_encrypt(msg, key):
    result = ""
    for char in msg:
        if char.isupper():
            result += chr((ord(char) - 65 + key) % 26 + 65)
        elif char.islower():
            result += chr((ord(char) - 97 + key) % 26 + 97)
        else:
            result += char
    return result

def caesar_decrypt(cipher, key):
    return caesar_encrypt(cipher, -key)

message = "Hello World"
key = 3
caesar_cipher = caesar_encrypt(message, key)
caesar_plain = caesar_decrypt(caesar_cipher, key)

print(f"Original: {message}")
print(f"Cipher:   {caesar_cipher}")
print(f"Decrypted: {caesar_plain}")