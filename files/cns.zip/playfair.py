def gen_matrix(key):
    key = "".join(sorted(set(key.upper()), key=key.upper().index)).replace('J', 'I')
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    matrix_str = key + "".join([c for c in alphabet if c not in key])
    return [list(matrix_str[i:i+5]) for i in range(0, 25, 5)]

def pos(mat, char):
    for r, row in enumerate(mat):
        if char in row:
            return (r, row.index(char))
    return (None, None)

def playfair(msg, mat):
    msg = msg.upper().replace('J', 'I').replace(' ', '')
    i = 0
    pairs = []
    while i < len(msg):
        a = msg[i]
        b = msg[i+1] if i+1 < len(msg) else 'X'
        if a == b:
            b = 'X'
            i -= 1
        pairs.append(a + b)
        i += 2
    
    cipher = ""
    for a, b in pairs:
        r1, c1 = pos(mat, a)
        r2, c2 = pos(mat, b)
        if r1 == r2:
            cipher += mat[r1][(c1 + 1) % 5] + mat[r2][(c2 + 1) % 5]
        elif c1 == c2:
            cipher += mat[(r1 + 1) % 5][c1] + mat[(r2 + 1) % 5][c2]
        else:
            cipher += mat[r1][c2] + mat[r2][c1]
    return cipher

key = "MONARCHY"
msg = "HELLO WORLD"
mat = gen_matrix(key)
cipher_text = playfair(msg, mat)
print(f"Keyword: {key}")
print(f"Message: {msg}")
print(f"Ciphertext: {cipher_text}")