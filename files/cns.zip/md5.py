import hashlib

def md5_digest(data: str) -> str:
    return hashlib.md5(data.encode('utf-8')).hexdigest()

def check_integrity(original: str, received: str):
    digest_orig = md5_digest(original)
    digest_recv = md5_digest(received)
    
    print(f"Original MD5: {digest_orig}")
    print(f"Received MD5: {digest_recv}")
    
    if digest_orig == digest_recv:
        print("Integrity Check: PASSED (Messages are identical)")
    else:
        print("Integrity Check: FAILED (Messages have been altered)")

original_msg = "Hello, this is a secure message."
received_msg_ok = "Hello, this is a secure message."
received_msg_bad = "Hello, this is a tampered message."

print("--- Test 1 (Match) ---")
check_integrity(original_msg, received_msg_ok)
print("\n--- Test 2 (Tampered) ---")
check_integrity(original_msg, received_msg_bad)