def modified_caesar_encrypt(msg, key):
    result = ""
    shift = key
    for char in msg:
        if char.isupper():
            result += chr((ord(char) - 65 + shift) % 26 + 65)
            shift += 1
        elif char.islower():
            result += chr((ord(char) - 97 + shift) % 26 + 97)
            shift += 1
        else:
            result += char
    return result

def modified_caesar_decrypt(cipher, key):
    result = ""
    shift = key
    for char in cipher:
        if char.isupper():
            result += chr((ord(char) - 65 - shift) % 26 + 65)
            shift += 1
        elif char.islower():
            result += chr((ord(char) - 97 - shift) % 26 + 97)
            shift += 1
        else:
            result += char
    return result

message = "Hello World"
key = 3

encrypted = modified_caesar_encrypt(message, key)
decrypted = modified_caesar_decrypt(encrypted, key)

print(f"Original:  {message}")
print(f"Encrypted: {encrypted}")
print(f"Decrypted: {decrypted}")