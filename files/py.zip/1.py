Integer =45
print("Integer:",Integer)
Float=4.345
print("Float:",Float)
Complex=3 + 4j
print("Complex:",Complex)
a=32
b=64
c=32
print(a<b or a>b)
print(a<b and a>b)
print(not a>b)
print( not a<b)
print(a<b & a>b)
print(a<b | a>b)
print(a<b ^ a>b)
print(~a<b)
print(~ a>b)
print(a<<2)
print(a>>2)
print(a is b)
print(c is a)
print(a is not b)
