list = [11,12,13,14,15]
print(list)

list.append(16)
print(list)

list2 = [17,18,19]
list.extend(list2)
print(list)

element = list[5]
print(element)

slicedList = list[1:4]
print(slicedList)

list.reverse()
print(list)

list.sort()
print(list)

length = len(list)
print(length)

index = list.index(16)
print(index)

