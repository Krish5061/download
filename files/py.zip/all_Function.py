#Built-In Functions:
print(len([1, 2, 3, 4]))

print(type(10))

print(max(10, 20, 30))

print(min([3, 7, 1, 9]))

print(sum([1, 2, 3, 4]))

print(sorted([3, 1, 4, 1, 5]))

#User-Defined Functions:
def hypotenuse(a, b):
    aSquare  = a**2
    bSquare = b**2
    result = math.sqrt(aSquare  + bSquare)
    return result

Side1 = 5
Side2 = 4
hypotenuse = hypotenuse(Side1, Side2)
print("The hypotenuse is : ", hypotenuse) 

#LAMBDA FUNCTION
add = lambda x, y: x + y
print(add(3, 5))

