import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.title("Tkinter Widgets Demo")
root.geometry("500x600")

# Label
label = tk.Label(root, text="Welcome to Tkinter!")
label.pack()

# Button
def button_clicked():
    print("Button was clicked!")
button = tk.Button(root, text="Press Me", command=button_clicked)
button.pack()

# Canvas
canvas = tk.Canvas(root, width=200, height=100)
canvas.pack()
canvas.create_rectangle(50, 20, 150, 80, fill="blue")

# Checkbutton
var = tk.IntVar()
checkbutton = tk.Checkbutton(root, text="Accept Terms", variable=var)
checkbutton.pack()

# Entry
entry = tk.Entry(root)
entry.pack()

# Frame
frame = tk.Frame(root, relief="raised", borderwidth=2)
frame.pack(padx=20, pady=20)
tk.Label(frame, text="Inside a Frame").pack()

# Listbox
listbox = tk.Listbox(root)
listbox.pack()
for item in ["Python", "Java", "C++"]:
    listbox.insert(tk.END, item)

# Menu
menu = tk.Menu(root)
root.config(menu=menu)
submenu = tk.Menu(menu, tearoff=0)
menu.add_cascade(label="File", menu=submenu)
submenu.add_command(label="Open")
submenu.add_command(label="Exit", command=root.quit)

# Message
message = tk.Message(root, text="This is a message widget with multiple lines of text.")
message.pack()

# Radiobutton
var_radio = tk.IntVar()
radio1 = tk.Radiobutton(root, text="Option 1", variable=var_radio, value=1)
radio2 = tk.Radiobutton(root, text="Option 2", variable=var_radio, value=2)
radio1.pack()
radio2.pack()

# Scale
scale = tk.Scale(root, from_=0, to=100, orient="horizontal")
scale.pack()

# Scrollbar with Text
text = tk.Text(root, height=5, width=30)
scroll = tk.Scrollbar(root, command=text.yview)
text.config(yscrollcommand=scroll.set)
text.pack(side="left")
scroll.pack(side="right", fill="y")

# Spinbox
spinbox = tk.Spinbox(root, from_=1, to=10)
spinbox.pack()

# Toplevel (New Window)
def open_new_window():
    new_window = tk.Toplevel(root)
    tk.Label(new_window, text="New Window").pack()
button_new_window = tk.Button(root, text="Open Window", command=open_new_window)
button_new_window.pack()

# PanedWindow
panedwindow = tk.PanedWindow(root, orient="horizontal")
panedwindow.pack(fill="both", expand=True)
left = tk.Label(panedwindow, text="Left Pane")
right = tk.Label(panedwindow, text="Right Pane")
panedwindow.add(left)
panedwindow.add(right)

# LabelFrame
labelframe = tk.LabelFrame(root, text="Group")
labelframe.pack()
tk.Label(labelframe, text="Inside LabelFrame").pack()

# Run the Tkinter event loop
root.mainloop()
