#Built-In Functions:

print(len([1, 2, 3, 4]))

print(type(10))

print("Hello", "World", sep=", ", end="!\n")

print(int("10"))
print(float("3.14"))
print(str(100))

print(list("abc"))
print(tuple([1, 2, 3]))
print(set("hello"))

print(max(10, 20, 30))
print(min([3, 7, 1, 9]))

print(sum([1, 2, 3, 4]))

print(sorted([3, 1, 4, 1, 5]))

print(list(range(5)))
print(list(range(1, 10, 2)))

#User-Defined Functions:

def greet(name):
    return f"Hello, {name}!"

print(greet("Alice"))

def add(a, b=10):
    return a + b

print(add(5))
print(add(5, 20))

def multiply(x, y):
    return x * y

print(multiply(4, 5))

#Anonymous (Lambda) Functions:

add = lambda x, y: x + y
print(add(3, 5))

hello = lambda: "Hello, World!"
print(hello())

numbers = [1, 2, 3, 4]
squared = list(map(lambda x: x**2, numbers))
print(squared)

even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)

words = ["apple", "banana", "cherry"]
sorted_words = sorted(words, key=lambda x: len(x))
print(sorted_words)
