#single inheritance
class Animal:
    def speak(self):
        print("Animal speaks")

class Dog(Animal):
    def bark(self):
        print("Dog barks")

dog = Dog()
dog.speak()  
dog.bark()  

#multilevel inheritance

class Grandparent:
    def family_name(self):
        print("Family Name: Smith")

class Parent(Grandparent):
    def parent_info(self):
        print("Parent: John Smith")

class Child(Parent):
    def child_info(self):
        print("Child: Alex Smith")

child = Child()
child.family_name()  
child.parent_info()  
child.child_info()   

#Hierarchical Inheritance:

class Vehicle:
    def general_info(self):
        print("This is a vehicle")

class Car(Vehicle):
    def car_info(self):
        print("Car has 4 wheels")

class Bike(Vehicle):
    def bike_info(self):
        print("Bike has 2 wheels")

car = Car()
car.general_info()
car.car_info()
bike = Bike()
bike.general_info()
bike.bike_info()

#Hybrid Inheritance:

class Engine:
    def engine_info(self):
        print("Engine type: Petrol")

class Body:
    def body_info(self):
        print("Body type: Sedan")

class Car(Engine):
    def car_info(self):
        print("This is a car")

class SportsCar(Car, Body):
    def sports_car_info(self):
        print("Sports car is fast")

sports_car = SportsCar()
sports_car.engine_info()    
sports_car.body_info()      
sports_car.car_info()       
sports_car.sports_car_info() 

#Cyclic Inheritance:

class CyclicClass(CyclicClass):  
    def __init__(self):
        print("CyclicClass constructor called")
        
    def example_method(self):
        print("Example method in CyclicClass")
        
obj = CyclicClass()
