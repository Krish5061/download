age = 18
if age >=18:
    print("you are an adult")

age = 12
if age >= 18:
    print("you are an adult")
else:
    print("you are a kid")

x = 7
y = 10
if x > 5:
    if y > 5:
        print("Both x and y are greater than 5")
    else:
        print("x is greater than 5 but y is not")
else:
    print("x is not greater than 5")
