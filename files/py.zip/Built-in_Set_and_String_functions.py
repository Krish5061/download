#SET METHOD
exes = {"Shreya", "Anushka", "Ashwini"}
exes.add("KrishShinde")
print(exes)

exes.clear()
print(exes)

exes = {"Shreya", "Anushka", "Ashwini"}
iForgot = exes.copy()
print(iForgot)

exes = {"Shreya", "Anushka","KrishShinde","Ashwini"}
friend = {"KrishShinde","Anooj"}          
diff = exes.difference(friend)   
print(diff)

exes = {"Shreya", "Anushka","KrishShinde","Ashwini"}
friend = {"KrishShinde","Anooj"}
exes.difference_update(friend)
print(exes)

exes = {"Shreya", "Anushka","KrishShinde","Ashwini"}          
friend = {"KrishShinde","Anooj"}          
common = exes.intersection(friend)          
print(common)          

#STRING METHOD

word = "my name is sujay sathe"          
res = word.capitalize()          
print(res)   

word = "Im about to cry"
res = word.upper()
print(res)

word = "Hello my name is SUJAY SATHE"
res = word.lower()
print(res)

myTuple = ("Sujay", "rishikesh", "armaan")
res = "#".join(myTuple)
print(res)

word = "im tired of doing python there are so many syntaxes"
res = word.title()
print(res)




       

