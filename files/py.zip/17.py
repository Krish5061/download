import matplotlib.pyplot as plt
import numpy as np

# Line Plot
x = np.linspace(0, 10, 100)  # Create an array of values from 0 to 10
y = np.sin(x)  # Compute sin(x)
plt.plot(x, y, label="sin(x)", color='b')  # Create a line plot
plt.title('Sine Wave')
plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.legend()
plt.grid()
plt.show()  # Display the plot

# Scatter Plot
x = np.random.rand(100)  # Random values for x-axis
y = np.random.rand(100)  # Random values for y-axis
plt.scatter(x, y, color='r', marker='o', alpha=0.7)  # Create a scatter plot
plt.title('Random Scatter Plot')
plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.grid()
plt.show()  # Display the plot

# Histogram
data = np.random.randn(1000)  # Random data following a normal distribution
plt.hist(data, bins=30, color='g', edgecolor='black', alpha=0.7)  # Create a histogram with 30 bins
plt.title('Histogram')
plt.xlabel('Values')
plt.ylabel('Frequency')
plt.grid()
plt.show()  # Display the plot
