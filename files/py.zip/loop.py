#While Loop

count = 0
while (count < 3):
    count = count + 1
    print("Hello World") 

#For Loop

s = "College"
for i in s:
    print(i)

#Nested Loops

for i in range(1, 4):
    for j in range(1, 4):
        print(i, j)
