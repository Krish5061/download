#Creating Tuples:

my_tuple = (1, 2, 3, 4, 5)
print("Tuple created:", my_tuple)

#Accessing Elements:

element = my_tuple[2]
print("Element at index 2:", element)
sliced_tuple = my_tuple[1:4]
print("Sliced tuple (index 1 to 3):", sliced_tuple)

#Tuple Information:

length = len(my_tuple)
print("Length of the tuple:", length)
existence = 3 in my_tuple
print("Does 3 exist in the tuple?", existence)
index = my_tuple.index(5)
print("Index of element 5:", index)

#Counting Occurrences:

count = my_tuple.count(2)
print("Occurrences of 2 in the tuple:", count)

#Join Tuple:

tuple1 = (1, 2, 3)
tuple2 = ('a', 'b', 'c')
joined_tuple = tuple1 + tuple2
print("Joined tuple (using + operator):", joined_tuple)
tuple3 = ('x', 'y')
tuple4 = (4, 5)
joined_tuple_2 = tuple3 + tuple4
print("Joined tuple (creating new tuple):", joined_tuple_2)
