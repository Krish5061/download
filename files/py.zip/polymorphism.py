#compile polymorphism
class Calculator:
    def add(self, a, b, c=None):
        if c is not None:
            return a + b + c
        else:
            return a + b


if __name__ == "__main__":
    calc = Calculator()
    print("Addition of 2 numbers:", calc.add(5, 3))
    print("Addition of 3 numbers:", calc.add(5, 3, 4))

#runtime polymorphism

class Animal:
    def speak(self):
        print("Animal speaks")

class Dog(Animal):
    
    def speak(self):
        print("Dog barks")

class Cat(Animal):
   
    def speak(self):
        print("Cat meows")



animal = Animal()
dog = Dog()
cat = Cat()

print("Animal speaking:")
animal.speak()

print("Dog speaking:")
dog.speak()

print("Cat speaking:")
cat.speak()
