#Classes and Objects:
class MyClass:
    def __init__(self, attribute1, attribute2):
        self.attribute1 = attribute1
        self.attribute2 = attribute2

    def display(self):
        print(f"Attribute 1: {self.attribute1}, Attribute 2: {self.attribute2}")

obj = MyClass("Hello", 123)
obj.display()

#Constructors:
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show_info(self):
        print(f"Name: {self.name}, Age: {self.age}")

person1 = Person("Alice", 25)
person1.show_info()

#Static Method:
class MathOperations:
    @staticmethod
    def add(a, b):
        return a + b

result = MathOperations.add(5, 3)
print("Sum:", result)


#Inner Class:
class OuterClass:
    def __init__(self, outer_attr):
        self.outer_attr = outer_attr
        print(f"OuterClass initialized with attribute: {self.outer_attr}")

    class InnerClass:
        def __init__(self, inner_attr):
            self.inner_attr = inner_attr
            print(f"InnerClass initialized with attribute: {self.inner_attr}")

outer_obj = OuterClass("OuterValue")

inner_obj = OuterClass.InnerClass("InnerValue")

